# Practica NoSQL redis para Bases de Datos 2

